package algonquin.cst2335.ni000017.data;

public class MainViewModel extends ViewModel
{
    public String editString;
}